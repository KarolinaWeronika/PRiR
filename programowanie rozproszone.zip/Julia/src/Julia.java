import java.util.concurrent.*;
import java.util.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

class JuliaTask implements Runnable {
    int [][] pixels;
    int startX, endX, startY, endY;

    JuliaTask(int [][] pixels, int startX, int endX, int startY, int endY) {
        this.pixels = pixels;
        this.startX = startX;
        this.endX = endX;
        this.startY = startY;
        this.endY = endY;
    }

    @Override
    public void run() {
        for (int y = startY; y < endY; ++y) {
            for (int x = startX; x < endX; ++x) {
                pixels[y][x] = calcColor(x, y);
            }
        }
    }


    int calcColor(int x, int y) {
        double cx = -0.8;
        double cy = 0.156;
        double R  = 1.6;
        double width  = pixels[0].length;
        double height = pixels.length;

        double zx = (x / width) * 2 * R - R;
        double zy = (y / height) * 2 * R - R;
        int iteration = 0;
        int maxIteration = 1000;
        while (zx * zx + zy * zy < R*R && iteration < maxIteration) {
            double xtemp = zx * zx - zy * zy;
            zy = 2 * zx * zy + cy;
            zx = xtemp + cx;
            ++iteration;
        }
        int color = 0;
        if (iteration < maxIteration) {
            float dist = iteration / (float)maxIteration;
            byte r = calcColorComponent(dist, 100, 1./4, 2.5);
            byte g = calcColorComponent(dist, 50, 1./2, 2.5);
            byte b = calcColorComponent(dist, 50, 3./4, 2.5);
            color = (r << 16) | (g << 8) | b;
        }
        return color;
    }

    static byte calcColorComponent(double x, double w, double c, double p) {
        return (byte)(Math.exp( -w * Math.pow(Math.abs(x - c), p) ) * 255);
    }
}

public class Julia {
    public static void main(String [] args) {
        final int N = 2000;
        int [][] pixels = new int[N][N];
        ForkJoinPool pool = ForkJoinPool.commonPool();
        //Java od wersji 1.7 udostępnia zestaw klas ułatwiających wykonywanie
        // obliczeń równoległych, w tym również zrównoleglanie algorytmów rekurencyjnych.
        // Służą do tego m.in. ForkJoinPool oraz RecursiveTask z pakietu java.util.concurrent.

        // ForkJoinPool jest również przydatne, gdy poszczególne podzadania nie są rekurencyjne.
        // W poniższym przykładzie każdy wyraz ciągu Fibonacciego wyznaczany jest w dokładnie
        // jednym zadaniu, które jednak nie są rekurencyjne. Wszystkie zadania wstawiane
        // są do puli, po czym wątek główny oczekuje na ich zakończenie i wyświetla wyniki.


        int tile = 100;
        for (int x = 0; x < N; x += tile) {
            for (int y = 0; y < N; y += tile) {
                pool.submit(new JuliaTask(pixels, x, x + tile, y, y + tile));
            }
        }


        BufferedImage image = new BufferedImage(N, N, BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < N; ++y) {
            image.setRGB(0, y, N, 1, pixels[y], 0, 0);
        }
        File outputfile = new File("julia.jpg");
        try {
            ImageIO.write(image, "jpg", outputfile);
        } catch(IOException e) {
            e.printStackTrace();
        }

    }
}