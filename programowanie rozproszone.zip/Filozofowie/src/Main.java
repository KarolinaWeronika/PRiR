
import java.sql.SQLOutput;
import java.util.Scanner;
import java.util.concurrent.Semaphore ;
public class Main extends Thread {
    static int MAX=100;
    static Semaphore [] widelec = new Semaphore [MAX] ;
    int mojNum;
    public Main ( int nr) {
        mojNum=nr ;
    }
    public void run ( ) {
        while ( true ) {
// myslenie
            System.out.println ( "Mysle jak usiasc¦ " + mojNum) ;
            try {
                Thread.sleep ( ( long ) (7000 * Math.random( ) ) ) ;
            } catch ( InterruptedException e ) {
            }
            widelec [mojNum].acquireUninterruptibly ( ) ; //przechwycenie L widelca
            widelec [ (mojNum+1)%MAX].acquireUninterruptibly ( ) ; //przechwycenie P widelca
// jedzenie
            System.out.println ( "Zaczynam jesc "+mojNum) ;
            try {
                Thread.sleep ( ( long ) (5000 * Math.random( ) ) ) ;
            } catch ( InterruptedException e ) {
            }
            System.out.println ( "Koncze jesc "+mojNum) ;
            widelec [mojNum].release ( ) ; //zwolnienie L widelca
            widelec [ (mojNum+1)%MAX].release ( ) ; //zwolnienie P widelca
        }
    }
    public void wlacz(){
        for (int i = 0; i < MAX; i++) {
            widelec[i] = new Semaphore(1);
        }
        for (int i = 0; i < MAX; i++) {
            new Main(i).start();
        }
    }

    public static void main(String[] args) {
        System.out.println("Wybierz program: \n1 - Problem 5 filozofów \n2 - Problem 5 filozofów z niesymetrycznym sięganiem po widelce\n3 - Rzut monety w rozwiązaniu problemu ucztujących Filozofów \n ");
        Scanner scanner = new Scanner(System.in);
        int pom = scanner.nextInt();
        System.out.println("Podaj ilosc filozofow: (od 2 do 100) ");
        Scanner scanner2 = new Scanner(System.in);
        int pom2 = scanner2.nextInt();

        if (pom == 1) {
            Main filozof1 = new Main(0);
            filozof1.MAX = pom2;
            filozof1.wlacz();

            }
        if (pom == 2) {
            Filozof2 filozof2 = new Filozof2(0);
            filozof2.MAX = pom2;
            filozof2.wlacz();
        }
        if (pom == 3) {
            Filozof3 filozof3 = new Filozof3(0);
            filozof3.MAX = pom2;
            filozof3.wlacz();
        }
    }
}
