import java.util.concurrent.Semaphore ;
public class Filozof2 extends Thread {
    static int MAX=100;
    static Semaphore [] widelec = new Semaphore [MAX] ;
    int mojNum;
    public Filozof2 ( int nr ) {
        mojNum=nr ;
    }
    public void run ( ) {
        while ( true ) {
// myslenie
            System.out.println ( "Mysle jak usiasc ¦ " + mojNum) ;
            try {
                Thread.sleep ( ( long ) (5000 * Math.random( ) ) ) ;
            } catch ( InterruptedException e ) {
            }
            if (mojNum == 0) {
                widelec [ (mojNum+1)%MAX].acquireUninterruptibly ( ) ;
                widelec [mojNum].acquireUninterruptibly ( ) ;
            } else {
                widelec [mojNum].acquireUninterruptibly ( ) ;
                widelec [ (mojNum+1)%MAX].acquireUninterruptibly ( ) ;
            }
// jedzenie
            System.out.println ( "Zaczynam jesc "+mojNum) ;
            try {
                Thread.sleep ( ( long ) (3000 * Math.random( ) ) ) ;
            } catch ( InterruptedException e ) {
            }
            System.out.println ( "Koncz3 jesc "+mojNum) ;
            widelec [mojNum].release ( ) ;
            widelec [ (mojNum+1)%MAX].release ( ) ;
        }
    }
    public void wlacz(){
        for ( int i =0; i<MAX; i++) {
            widelec[ i ]=new Semaphore ( 1 ) ;
        }
        for ( int i =0; i<MAX; i++) {
            new Filozof2(i).start();
        }
    }


}
