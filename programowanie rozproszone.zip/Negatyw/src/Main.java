import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
public class Main extends Thread {
    BufferedImage image;
    int pw;
    int kw;
    int ps;
    int ks;

    public Main(int pw, int kw, int ps, int ks, BufferedImage img) throws IOException {
        this.image = img;
        this.pw = pw;
        this.kw = kw;
        this.ps = ps;
        this.ks = ks;
    }

    public void run() {
        try {
            for (int i = pw; i < kw - 1; i++) {
                for (int j = ps; j < ks - 1; j++) {

                    //odczyt składowych koloru RGB
                    Color c = new Color(image.getRGB(j, i));
                    int red = (int) (c.getRed());
                    int green = (int) (c.getGreen());
                    int blue = (int) (c.getBlue());

                    int final_red, final_green, final_blue;

                    //negatyw
                    final_red = 255 - red;
                    final_green = 255 - green;
                    final_blue = 255 - blue;
                    Color newColor = new Color(final_red, final_green, final_blue);
                    image.setRGB(j, i, newColor.getRGB());
                } //koniec dwóch pętli po kolumnach i wierszach obrazu
            }
            //zapis do pliku zmodyfikowanego obrazu
            File ouptut = new File("negatyw_przerobione.jpg");
            ImageIO.write(image, "jpg", ouptut);
        } catch (Exception e) {
        }
    }

    static public void main(String args[]) throws Exception {
        BufferedImage image;
        int width;
        int height;
        File input = new File("lablador.jpg");
        image = ImageIO.read(input);
        width = image.getWidth();
        height = image.getHeight();
        Main obj = new Main(0, height/2 +1, 0, width/2+1, image);
        Main obj2 = new Main(0, height/2, width/2, width, image);
        Main obj3 = new Main(height/2, height, 0, width/2, image);
        Main obj4 = new Main(height/2-1, height, width/2-1, width, image);
        obj.start();
        obj2.start();
        obj3.start();
        obj4.start();

    }
}