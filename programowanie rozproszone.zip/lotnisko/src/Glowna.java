public class Glowna {
    static int ilosc_zamowien=10;
    static int ilosc_barmanek=8;
    static Kawiarnia kawiarnia;
    public Glowna(){
    }
    public static void main(String[] args) {
        kawiarnia=new Kawiarnia(ilosc_barmanek, ilosc_zamowien);
        for(int i=0;i<ilosc_zamowien;i++)
            new Kawa(i,20,kawiarnia).start();
    }
}
