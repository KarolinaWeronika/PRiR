public class Kawiarnia {
    static int KAWIARNIA=1;
    static int WYADANA=2;
    static int ZAMOWIENIE=4;
    int ilosc_barmanek;
    int ilosc_zajetych;
    int ilosc_zamowien;
    Kawiarnia(int ilosc_pasow,int ilosc_samolotow){
        this.ilosc_barmanek=ilosc_pasow;
        this.ilosc_zamowien=ilosc_samolotow;
        this.ilosc_zajetych=0;
    }
    synchronized int start(int numer){
        ilosc_zajetych--;
        System.out.println("Uzupelnione zasoby na kawe "+numer);
        return WYADANA;
    }
    synchronized int laduj(){
        try{
            Thread.currentThread().sleep(1000);//sleep for 1000 ms
        }
        catch(Exception ie){
        }
        if(ilosc_zajetych<ilosc_barmanek){
            ilosc_zajetych++;
            System.out.println("Przyjeto zamowienie przez barmanke "+ilosc_zajetych);
            return KAWIARNIA;
        }
        else
        {return ZAMOWIENIE;}
    }
    synchronized void zmniejsz(){
        ilosc_zamowien--;
        System.out.println("Barmanka zle zrobila kawe");
        if(ilosc_zamowien==ilosc_barmanek) System.out.println("ILOSC ZAMOWIEN TAKA SAMA JAK ILOSC BARMANOW ______________");
    }
}
