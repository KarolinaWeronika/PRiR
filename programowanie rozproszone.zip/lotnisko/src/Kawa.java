import java.util.Random;
public class Kawa extends Thread {
    //definicja stanˇw samolotu
    static int KAWIARNIA = 1;
    static int WYADANA = 2;
    static int UZUPELNIENIE = 3;
    static int ZAMOWIENIE = 4;
    static int KATASTROFA = 5;
    static int ZAPLAC = 20;
    static int KWOTA = 20;
    //zmienne pomocnicze
    int numer;
    int cena;
    int stan;
    Kawiarnia l;
    Random rand;

    public Kawa(int numer, int cena, Kawiarnia l) {
        this.numer = numer;
        this.cena = cena;
        this.stan = UZUPELNIENIE;
        this.l = l;
        rand = new Random();
    }

    public void run() {
        while (true) {
            if (stan == KAWIARNIA) {
                if (rand.nextInt(2) == 1) {
                    stan = WYADANA;
                    cena = ZAPLAC;
                    System.out.println("Wydana klientowi kawa " + numer);
                    stan = l.start(numer);
                } else {
                    System.out.println("Barmanka czeka w kolejce do ekspresu");
                }
            } else if (stan == WYADANA) {
                System.out.println("Barmanka informuje, ze mozna znowu zamawiac kawe  " + numer);
                stan = UZUPELNIENIE;
            } else if (stan == UZUPELNIENIE) {
                cena -= rand.nextInt(10);
                if (cena <= KWOTA) {
                    stan = ZAMOWIENIE;
                } else try {
                    sleep(rand.nextInt(20));
                } catch (Exception e) {
                }
            } else if (stan == ZAMOWIENIE) {
                System.out.println("Klient zamawia kawe " + numer + ", cena " + cena);
                stan = l.laduj();
                if (stan == ZAMOWIENIE) {
                    cena -= rand.nextInt(10);

                    if (cena <= 0) {
                        stan = KATASTROFA;
                        cena=0;
                    }
                    System.out.println("KLIENT NIE ZAPLACIL pełnej sumy o " + cena);
                }
            } else if (stan == KATASTROFA) {
                System.out.println("Klient nie odebral kawy " + numer);
                l.zmniejsz();
            }
        }
    }
}
